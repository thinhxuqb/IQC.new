/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  AuditLog, 
  CapaRecord, 
  Instrument, 
  InstrumentId, 
  LabInfo,
  MeanSdAuditRecord, 
  QCLot, 
  QCMaterial,
  QCMapping,
  QCResult, 
  TestAssay, 
  UserProfile 
} from './types/qc';
import { 
  AppStateData, 
  loadAppState, 
  saveAssays, 
  saveAuditLog, 
  saveCurrentUser, 
  saveInstruments, 
  saveLabInfo,
  saveLots, 
  saveMaterials,
  saveQCMappings,
  saveMeanSdAuditHistory, 
  saveResults,
  saveUsers 
} from './utils/qcStorage';
import { Header } from './components/Header';
import { DashboardView } from './components/DashboardView';
import { LeveyJenningsChart } from './components/LeveyJenningsChart';
import { MultiChartGridView } from './components/MultiChartGridView';
import { MachineSignalReceiver } from './components/MachineSignalReceiver';
import { CapaListView } from './components/CapaListView';
import { BackupRestoreView } from './components/BackupRestoreView';
import { QCConfigView } from './components/QCConfigView';
import { UserRoleSwitcherModal } from './components/UserRoleSwitcherModal';
import { CapaModal } from './components/CapaModal';
import { ManualEntryModal } from './components/ManualEntryModal';
import { QCReportModal } from './components/QCReportModal';
import { LoginModal } from './components/LoginModal';
import { UpdateCheckModal } from './components/UpdateCheckModal';
import { LabInfoModal } from './components/LabInfoModal';
import { checkGitHubReleaseUpdate, UpdateInfo } from './services/updateService';
import { 
  AlertTriangle, 
  Activity, 
  Filter, 
  CheckCircle, 
  ArrowRight, 
  X,
  FileText,
  Sparkles,
  Download
} from 'lucide-react';

export default function App() {
  const [appState, setAppState] = useState<AppStateData>(loadAppState);
  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [selectedAssayId, setSelectedAssayId] = useState<string>('AU_GLU');
  
  // Trạng thái mạng
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine ?? true);
  const [pendingSyncCount, setPendingSyncCount] = useState<number>(0);

  // Modals
  const [isUserModalOpen, setIsUserModalOpen] = useState<boolean>(false);
  const [isCapaModalOpen, setIsCapaModalOpen] = useState<boolean>(false);
  const [selectedResultForCapa, setSelectedResultForCapa] = useState<QCResult | null>(null);
  const [isManualEntryOpen, setIsManualEntryOpen] = useState<boolean>(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState<boolean>(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState<boolean>(false);
  const [isUpdateModalOpen, setIsUpdateModalOpen] = useState<boolean>(false);
  const [isLabInfoModalOpen, setIsLabInfoModalOpen] = useState<boolean>(false);
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => localStorage.getItem('qc_lab_is_logged_in') !== 'false');
  const [syncToastMessage, setSyncToastMessage] = useState<string | null>(null);

  const handleLogout = () => {
    const log: AuditLog = {
      id: `log_logout_${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: appState.currentUser.id,
      userName: appState.currentUser.name,
      role: appState.currentUser.role,
      action: 'ĐĂNG_XUẤT_HỆ_THỐNG',
      details: `Người dùng ${appState.currentUser.name} (@${appState.currentUser.username}) đã đăng xuất khỏi hệ thống.`,
    };
    saveAuditLog(log);
    setAppState((prev) => ({ ...prev, logs: [log, ...prev.logs] }));
    setIsUserModalOpen(false);
    setIsManualEntryOpen(false);
    setIsReportModalOpen(false);
    setIsLabInfoModalOpen(false);
    setIsLoggedIn(false);
    localStorage.setItem('qc_lab_is_logged_in', 'false');
  };

  // Bản cập nhật mới phát hiện khi khởi động
  const [availableUpdate, setAvailableUpdate] = useState<UpdateInfo | null>(null);
  const [dismissedUpdatePrompt, setDismissedUpdatePrompt] = useState<boolean>(false);

  // Toast thông báo tức thì khi máy truyền kết quả vi phạm
  const [activeAlert, setActiveAlert] = useState<{
    result: QCResult;
    title: string;
    description: string;
  } | null>(null);

  // Theo dõi sự kiện online / offline của trình duyệt
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Tự động quét bản cập nhật mới trên GitHub khi khởi động ứng dụng
  useEffect(() => {
    const autoCheck = localStorage.getItem('iqc_auto_check_update') !== 'false';
    if (autoCheck) {
      const timer = setTimeout(() => {
        checkGitHubReleaseUpdate().then((info) => {
          if (info.hasUpdate) {
            setAvailableUpdate(info);
            // Tự động mở hộp thoại hỏi người dùng có đồng ý cập nhật không
            setIsUpdateModalOpen(true);
          }
        }).catch((err) => {
          console.warn('Lỗi kiểm tra bản cập nhật khi khởi động:', err);
        });
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, []);

  // Đếm số sự cố CAPA chưa hoàn tất
  const unresolvedCapaCount = appState.results.filter(
    (r) => (r.status === 'REJECTED' || r.status === 'WARNING') && (!r.capa || r.capa.status === 'PENDING_APPROVAL')
  ).length;

  // Thêm kết quả QC mới (từ máy LIS hoặc nhập tay)
  const handleAddNewResult = (newResult: QCResult) => {
    const log: AuditLog = {
      id: `log_${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: appState.currentUser.id,
      userName: appState.currentUser.name,
      role: appState.currentUser.role,
      action: newResult.source === 'MÁY_XÉT_NGHIỆM_LIS' ? 'NHẬN_TÍN_HIỆU_LIS' : 'NHẬP_QC_THỦ_CÔNG',
      details: `${newResult.source}: ${newResult.assayId} (${newResult.level}) = ${newResult.value}. Trạng thái: ${newResult.status}.`,
      instrumentId: newResult.instrumentId,
    };
    saveAuditLog(log);

    setAppState((prev) => {
      const updatedResults = [...prev.results, newResult];
      saveResults(updatedResults);

      // Bảo đảm lô QC tồn tại trong danh mục lots nếu xét nghiệm mới chưa được gán lô
      let updatedLots = prev.lots;
      const hasLot = prev.lots.some((l) => l.assayId === newResult.assayId && l.level === newResult.level);
      if (!hasLot) {
        const fallbackLot: QCLot = {
          id: newResult.lotId || `LOT_${newResult.assayId}_${newResult.level}`,
          assayId: newResult.assayId,
          instrumentId: newResult.instrumentId,
          lotNumber: 'QC-STD',
          level: newResult.level,
          levelName: newResult.level === 'level1' ? 'Mức 1 (Level 1)' : newResult.level === 'level2' ? 'Mức 2 (Level 2)' : 'Mức 3 (Level 3)',
          manufacturer: 'Chuẩn Nội Kiểm',
          controlName: 'QC Control',
          expDate: '2028-12-31',
          targetMean: Number(newResult.value.toFixed(2)),
          targetSD: 0.5,
          targetCV: 5.0,
          active: true,
        };
        updatedLots = [...prev.lots, fallbackLot];
        saveLots(updatedLots);
      }

      return {
        ...prev,
        results: updatedResults,
        lots: updatedLots,
        logs: [log, ...prev.logs],
      };
    });

    // Kích hoạt chuông thông báo nếu có vi phạm Westgard
    if (newResult.status === 'REJECTED' || newResult.status === 'WARNING') {
      setActiveAlert({
        result: newResult,
        title: newResult.status === 'REJECTED' ? 'Cảnh Báo Vi Phạm Westgard (Từ Chối / Reject)' : 'Cảnh Báo Theo Dõi (Warning 1-2s)',
        description: newResult.violations.length > 0 
          ? `${newResult.violations.map(v => v.ruleName).join(', ')}: ${newResult.violations[0].description}`
          : `Giá trị ${newResult.value} vượt ngưỡng kiểm soát.`,
      });
    }
  };

  // Thêm hàng loạt kết quả QC cùng lúc từ bảng Worksheet
  const handleAddNewResults = (newResults: QCResult[]) => {
    if (!newResults || newResults.length === 0) return;

    const log: AuditLog = {
      id: `log_batch_${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: appState.currentUser.id,
      userName: appState.currentUser.name,
      role: appState.currentUser.role,
      action: 'NHẬP_QC_HÀNG_LOẠT',
      details: `Đã nhập bảng kết quả nội kiểm hàng loạt gồm ${newResults.length} giá trị xét nghiệm và các mức.`,
      instrumentId: newResults[0]?.instrumentId,
    };
    saveAuditLog(log);

    setAppState((prev) => {
      const updatedResults = [...prev.results, ...newResults];
      saveResults(updatedResults);

      // Bảo đảm tất cả các lô QC được nhập đều có trong danh mục lots
      let updatedLots = [...prev.lots];
      let lotsChanged = false;
      newResults.forEach((res) => {
        const hasLot = updatedLots.some((l) => l.assayId === res.assayId && l.level === res.level);
        if (!hasLot) {
          lotsChanged = true;
          updatedLots.push({
            id: res.lotId || `LOT_${res.assayId}_${res.level}`,
            assayId: res.assayId,
            instrumentId: res.instrumentId,
            lotNumber: 'QC-STD',
            level: res.level,
            levelName: res.level === 'level1' ? 'Mức 1 (Level 1)' : res.level === 'level2' ? 'Mức 2 (Level 2)' : 'Mức 3 (Level 3)',
            manufacturer: 'Chuẩn Nội Kiểm',
            controlName: 'QC Control',
            expDate: '2028-12-31',
            targetMean: Number(res.value.toFixed(2)),
            targetSD: 0.5,
            targetCV: 5.0,
            active: true,
          });
        }
      });
      if (lotsChanged) {
        saveLots(updatedLots);
      }

      return {
        ...prev,
        results: updatedResults,
        lots: updatedLots,
        logs: [log, ...prev.logs],
      };
    });

    // Bật cảnh báo nếu có vi phạm
    const firstViolation = newResults.find(r => r.status === 'REJECTED') || newResults.find(r => r.status === 'WARNING');
    if (firstViolation) {
      setActiveAlert({
        result: firstViolation,
        title: firstViolation.status === 'REJECTED' ? 'Cảnh Báo Vi Phạm Westgard (Batch Entry)' : 'Cảnh Báo Theo Dõi (1-2s)',
        description: firstViolation.violations.length > 0 
          ? `${firstViolation.violations.map(v => v.ruleName).join(', ')}: ${firstViolation.violations[0].description}`
          : `Có ${newResults.filter(r => r.status === 'REJECTED').length} xét nghiệm bị vi phạm quy tắc Westgard cần xem xét.`,
      });
    }
  };

  // Cập nhật hồ sơ CAPA
  const handleSaveCapa = (resultId: string, capa: CapaRecord) => {
    const updatedResults = appState.results.map((r) => {
      if (r.id === resultId) {
        return {
          ...r,
          capa,
        };
      }
      return r;
    });

    saveResults(updatedResults);

    const log: AuditLog = {
      id: `log_capa_${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: appState.currentUser.id,
      userName: appState.currentUser.name,
      role: appState.currentUser.role,
      action: capa.status === 'RESOLVED' ? 'PHÊ_DUYỆT_CAPA' : 'CẬP_NHẬT_CAPA',
      details: `Hồ sơ CAPA cho lượt chạy ${resultId}. Trạng thái: ${capa.status}. Người thực hiện: ${capa.resolvedBy}.`,
    };
    saveAuditLog(log);

    setAppState((prev) => ({
      ...prev,
      results: updatedResults,
      logs: [log, ...prev.logs],
    }));

    if (activeAlert?.result.id === resultId) {
      setActiveAlert(null);
    }
  };

  // Đổi người dùng / vai trò
  const handleSelectUser = (user: UserProfile) => {
    saveCurrentUser(user);
    const log: AuditLog = {
      id: `log_usr_${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: user.id,
      userName: user.name,
      role: user.role,
      action: 'CHUYỂN_ĐỔI_VAI_TRÒ',
      details: `Đăng nhập vai trò: ${user.roleTitle}`,
    };
    saveAuditLog(log);

    setAppState((prev) => ({
      ...prev,
      currentUser: user,
      logs: [log, ...prev.logs],
    }));
  };

  // Đồng bộ cưỡng bức
  const handleForceSync = () => {
    setTimeout(() => {
      setPendingSyncCount(0);
      setSyncToastMessage('Đã đồng bộ toàn bộ cơ sở dữ liệu nội kiểm với máy chủ đám mây an toàn.');
      setTimeout(() => setSyncToastMessage(null), 4000);
    }, 400);
  };

  // Cập nhật Lô QC (bao gồm sửa Mean/SD có lưu vết)
  const handleUpdateLot = (updatedLot: QCLot, auditRecord?: MeanSdAuditRecord) => {
    let updatedLots: QCLot[];
    const exists = appState.lots.some((l) => l.id === updatedLot.id);
    if (exists) {
      updatedLots = appState.lots.map((l) => (l.id === updatedLot.id ? updatedLot : l));
    } else {
      updatedLots = [...appState.lots, updatedLot];
    }
    saveLots(updatedLots);

    let updatedAuditHistory = appState.meanSdAuditHistory || [];
    let updatedLogs = appState.logs;

    if (auditRecord) {
      updatedAuditHistory = [auditRecord, ...updatedAuditHistory];
      saveMeanSdAuditHistory(updatedAuditHistory);

      const log: AuditLog = {
        id: `log_msd_${Date.now()}`,
        timestamp: new Date().toISOString(),
        userId: appState.currentUser.id,
        userName: appState.currentUser.name,
        role: appState.currentUser.role,
        action: 'HIỆU_CHỈNH_MEAN_SD',
        details: `Hiệu chỉnh Mean & SD Lô ${updatedLot.lotNumber} (${updatedLot.levelName}) - ${auditRecord.assayName}. Mean: ${auditRecord.oldMean} -> ${auditRecord.newMean}, SD: ${auditRecord.oldSD} -> ${auditRecord.newSD}. Lý do: ${auditRecord.reason}`,
        instrumentId: updatedLot.instrumentId,
      };
      saveAuditLog(log);
      updatedLogs = [log, ...updatedLogs];
    }

    setAppState((prev) => ({
      ...prev,
      lots: updatedLots,
      meanSdAuditHistory: updatedAuditHistory,
      logs: updatedLogs,
    }));
  };

  // Xóa Lô QC
  const handleDeleteLot = (lotId: string) => {
    const updatedLots = appState.lots.filter((l) => l.id !== lotId);
    saveLots(updatedLots);
    setAppState((prev) => ({ ...prev, lots: updatedLots }));
  };

  // Thêm / Sửa Xét nghiệm
  const handleSaveAssay = (assay: TestAssay) => {
    let updatedAssays: TestAssay[];
    const exists = appState.assays.some((a) => a.id === assay.id);
    if (exists) {
      updatedAssays = appState.assays.map((a) => (a.id === assay.id ? assay : a));
    } else {
      updatedAssays = [...appState.assays, assay];
    }
    saveAssays(updatedAssays);
    setAppState((prev) => ({ ...prev, assays: updatedAssays }));
  };

  // Xóa Xét nghiệm
  const handleDeleteAssay = (assayId: string) => {
    const updatedAssays = appState.assays.filter((a) => a.id !== assayId);
    saveAssays(updatedAssays);
    setAppState((prev) => ({ ...prev, assays: updatedAssays }));
  };

  // Thêm / Sửa Thiết bị
  const handleSaveInstrument = (inst: Instrument) => {
    let updatedInstruments: Instrument[];
    const exists = appState.instruments.some((i) => i.id === inst.id);
    if (exists) {
      updatedInstruments = appState.instruments.map((i) => (i.id === inst.id ? inst : i));
    } else {
      updatedInstruments = [...appState.instruments, inst];
    }
    saveInstruments(updatedInstruments);
    setAppState((prev) => ({ ...prev, instruments: updatedInstruments }));
  };

  // Xóa Thiết bị
  const handleDeleteInstrument = (instId: string) => {
    const updatedInstruments = appState.instruments.filter((i) => i.id !== instId);
    saveInstruments(updatedInstruments);
    setAppState((prev) => ({ ...prev, instruments: updatedInstruments }));
  };

  // Thêm / Sửa Người Dùng & Phân Quyền
  const handleSaveUser = (user: UserProfile) => {
    const isAdminAccount = user.id === 'user_admin' || user.username.toLowerCase() === 'admin';
    const normalizedUser: UserProfile = isAdminAccount
      ? {
          ...user,
          username: 'admin',
          role: 'director',
          active: true,
          permissions: {
            canInputQC: true,
            canEditMeanSD: true,
            canApproveCapa: true,
            canManageConfig: true,
            canManageUsers: true,
            canExportReports: true,
            canResetDatabase: true,
            canEditLabInfo: true,
          },
        }
      : user;

    let updatedUsers: UserProfile[];
    const exists = (appState.users || []).some((u) => u.id === normalizedUser.id);
    if (exists) {
      updatedUsers = (appState.users || []).map((u) => (u.id === normalizedUser.id ? normalizedUser : u));
    } else {
      updatedUsers = [...(appState.users || []), normalizedUser];
    }
    saveUsers(updatedUsers);

    const isSelf = appState.currentUser.id === normalizedUser.id;

    const log: AuditLog = {
      id: `log_usr_${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: appState.currentUser.id,
      userName: appState.currentUser.name,
      role: appState.currentUser.role,
      action: exists ? 'CẬP_NHẬT_NGƯỜI_DÙNG' : 'TẠO_NGƯỜI_DÙNG_MỚI',
      details: `${exists ? 'Cập nhật tài khoản & phân quyền' : 'Khai báo người dùng mới'}: ${normalizedUser.name} (@${normalizedUser.username}) - ${normalizedUser.roleTitle}`,
    };
    saveAuditLog(log);

    setAppState((prev) => ({
      ...prev,
      users: updatedUsers,
      currentUser: isSelf ? normalizedUser : prev.currentUser,
      logs: [log, ...prev.logs],
    }));
  };

  // Xóa Người Dùng (Không cho phép xóa tài khoản admin mặc định)
  const handleDeleteUser = (userId: string) => {
    const target = (appState.users || []).find((u) => u.id === userId);
    if (!target || target.id === 'user_admin' || target.username.toLowerCase() === 'admin') {
      return;
    }
    const updatedUsers = (appState.users || []).filter((u) => u.id !== userId);
    saveUsers(updatedUsers);
    setAppState((prev) => ({ ...prev, users: updatedUsers }));
  };

  // Thêm / Sửa Vật Liệu QC
  const handleSaveMaterial = (mat: QCMaterial) => {
    let updatedMaterials: QCMaterial[];
    const exists = (appState.materials || []).some((m) => m.id === mat.id);
    if (exists) {
      updatedMaterials = (appState.materials || []).map((m) => (m.id === mat.id ? mat : m));
    } else {
      updatedMaterials = [...(appState.materials || []), mat];
    }
    saveMaterials(updatedMaterials);
    setAppState((prev) => ({ ...prev, materials: updatedMaterials }));
  };

  // Xóa Vật Liệu QC
  const handleDeleteMaterial = (matId: string) => {
    const updatedMaterials = (appState.materials || []).filter((m) => m.id !== matId);
    saveMaterials(updatedMaterials);
    setAppState((prev) => ({ ...prev, materials: updatedMaterials }));
  };

  // Thêm / Sửa Map Kiểm Chuẩn (Ghép Nối & Cài Mean/SD từng mức)
  const handleSaveMapping = (mapping: QCMapping) => {
    let updatedMappings: QCMapping[];
    const exists = (appState.qcMappings || []).some((m) => m.id === mapping.id);
    if (exists) {
      updatedMappings = (appState.qcMappings || []).map((m) => (m.id === mapping.id ? mapping : m));
    } else {
      updatedMappings = [...(appState.qcMappings || []), mapping];
    }
    saveQCMappings(updatedMappings);

    // Đồng bộ sang danh mục QCLot để bảo đảm các biểu đồ Levey-Jennings, LIS và Westgard chạy trơn tru
    const material = (appState.materials || []).find((m) => m.id === mapping.materialId);
    let updatedLots = [...appState.lots];

    mapping.levelConfigs.forEach((lvl) => {
      const lotId = lvl.lotId || `LOT_${mapping.assayId}_${lvl.level}`;
      const existingLotIndex = updatedLots.findIndex((l) => l.id === lotId || (l.assayId === mapping.assayId && l.level === lvl.level));

      const syncedLot: QCLot = {
        id: lotId,
        assayId: mapping.assayId,
        instrumentId: mapping.instrumentId,
        lotNumber: material?.lotNumber || 'QC-LOT',
        level: lvl.level,
        levelName: lvl.levelName,
        manufacturer: material?.manufacturer || 'Bio-Rad',
        controlName: material?.name || 'QC Control',
        expDate: material?.expDate || '2027-12-31',
        targetMean: lvl.targetMean,
        targetSD: lvl.targetSD,
        targetCV: lvl.targetCV,
        active: lvl.active && mapping.active,
        materialId: mapping.materialId,
      };

      if (existingLotIndex >= 0) {
        updatedLots[existingLotIndex] = { ...updatedLots[existingLotIndex], ...syncedLot };
      } else {
        updatedLots.push(syncedLot);
      }
    });

    saveLots(updatedLots);
    setAppState((prev) => ({ ...prev, qcMappings: updatedMappings, lots: updatedLots }));
  };

  // Xóa Map Kiểm Chuẩn
  const handleDeleteMapping = (mappingId: string) => {
    const updatedMappings = (appState.qcMappings || []).filter((m) => m.id !== mappingId);
    saveQCMappings(updatedMappings);
    setAppState((prev) => ({ ...prev, qcMappings: updatedMappings }));
  };

  // Cập nhật Thông Tin Phòng Xét Nghiệm
  const handleSaveLabInfo = (info: LabInfo) => {
    saveLabInfo(info);
    const log: AuditLog = {
      id: `log_lab_${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: appState.currentUser.id,
      userName: appState.currentUser.name,
      role: appState.currentUser.role,
      action: 'CẬP_NHẬT_THÔNG_TIN_PHÒNG_XÉT_NGHIỆM',
      details: `Cập nhật hồ sơ cơ sở: ${info.hospitalName} · ${info.name}. Trưởng khoa: ${info.headOfDepartment}.`,
    };
    saveAuditLog(log);
    setAppState((prev) => ({
      ...prev,
      labInfo: info,
      logs: [log, ...prev.logs],
    }));
  };

  const selectedAssay = appState.assays.find((a) => a.id === selectedAssayId) || appState.assays[0];
  const selectedAssayLots = appState.lots.filter((l) => l.assayId === selectedAssay?.id);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      {/* Global Header */}
      <Header
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        currentUser={appState.currentUser}
        onOpenUserModal={() => setIsUserModalOpen(true)}
        onLogout={handleLogout}
        onLogin={() => setIsLoginModalOpen(true)}
        isLoggedIn={isLoggedIn}
        isOnline={isOnline}
        pendingSyncCount={pendingSyncCount}
        unresolvedCapaCount={unresolvedCapaCount}
        onOpenUpdateModal={() => setIsUpdateModalOpen(true)}
        labInfo={appState.labInfo}
        onOpenLabInfoModal={() => setIsLabInfoModalOpen(true)}
      />

      {/* Auto Update Available Confirmation Banner (Hỏi đồng ý cập nhật) */}
      {availableUpdate && !dismissedUpdatePrompt && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-3 w-full no-print">
          <div className="p-4 rounded-xl border border-indigo-300 bg-gradient-to-r from-indigo-50 via-sky-50 to-indigo-100 text-indigo-950 shadow-md flex flex-wrap items-center justify-between gap-4 animate-in slide-in-from-top-2">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-xs shrink-0">
                <Sparkles className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <h4 className="font-bold text-sm flex items-center gap-2">
                  <span>Phát hiện bản cập nhật mới: {availableUpdate.latestVersion}</span>
                  <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-indigo-200 text-indigo-900 font-bold">
                    Khuyên dùng
                  </span>
                </h4>
                <p className="text-xs text-indigo-800 mt-0.5 max-w-2xl">
                  {availableUpdate.releaseName} — Bạn có muốn đồng ý cập nhật ứng dụng ngay bây giờ để nhận các tính năng và sửa lỗi mới nhất?
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsUpdateModalOpen(true)}
                className="px-3.5 py-2 bg-indigo-700 hover:bg-indigo-800 text-white rounded-lg text-xs font-bold shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Đồng Ý Cập Nhật</span>
              </button>
              <button
                onClick={() => setDismissedUpdatePrompt(true)}
                className="px-3 py-2 bg-white/80 hover:bg-white text-indigo-900 border border-indigo-200 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
              >
                Để Sau
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Instant Westgard Incident Alert Toast */}
      {activeAlert && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-4 w-full no-print">
          <div className={`p-4 rounded-xl border shadow-md flex items-start justify-between gap-4 animate-in slide-in-from-top-3 ${
            activeAlert.result.status === 'REJECTED'
              ? 'bg-rose-50 border-rose-300 text-rose-950'
              : 'bg-amber-50 border-amber-300 text-amber-950'
          }`}>
            <div className="flex items-start gap-3">
              <div className={`p-2 rounded-lg shrink-0 ${
                activeAlert.result.status === 'REJECTED' ? 'bg-rose-200 text-rose-800' : 'bg-amber-200 text-amber-800'
              }`}>
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-sm flex items-center gap-2">
                  <span>{activeAlert.title}</span>
                  <span className="font-mono text-xs font-normal">
                    [{activeAlert.result.instrumentId} · {activeAlert.result.assayId}]
                  </span>
                </h4>
                <p className="text-xs mt-1 text-slate-700">
                  {activeAlert.description}
                </p>
                <div className="mt-2 flex items-center gap-3">
                  <button
                    onClick={() => {
                      setSelectedResultForCapa(activeAlert.result);
                      setIsCapaModalOpen(true);
                    }}
                    className="text-xs font-bold bg-slate-900 text-white px-3 py-1 rounded-md hover:bg-slate-800 transition-colors"
                  >
                    Xử lý CAPA ngay
                  </button>
                  <button
                    onClick={() => {
                      setSelectedAssayId(activeAlert.result.assayId);
                      setCurrentTab('chart');
                      setActiveAlert(null);
                    }}
                    className="text-xs font-semibold text-slate-700 hover:text-slate-900 underline"
                  >
                    Xem trên biểu đồ L-J
                  </button>
                </div>
              </div>
            </div>

            <button
              onClick={() => setActiveAlert(null)}
              className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Sync Notification Toast */}
      {syncToastMessage && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-4 w-full no-print">
          <div className="p-4 rounded-xl border border-emerald-300 bg-emerald-50 text-emerald-950 shadow-md flex items-center justify-between gap-4 animate-in slide-in-from-top-3">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-emerald-200 text-emerald-800 shrink-0">
                <CheckCircle className="w-5 h-5" />
              </div>
              <p className="text-xs sm:text-sm font-semibold text-emerald-900">
                {syncToastMessage}
              </p>
            </div>
            <button
              onClick={() => setSyncToastMessage(null)}
              className="text-emerald-700 hover:text-emerald-900 p-1 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Main Content Area (Strict Auth Guard: Yêu cầu đăng nhập mới hiển thị dữ liệu) */}
      {isLoggedIn ? (
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {/* Tab 1: Dashboard */}
          {currentTab === 'dashboard' && (
            <DashboardView
              instruments={appState.instruments}
              assays={appState.assays}
              lots={appState.lots}
              results={appState.results}
              currentUser={appState.currentUser}
              onSelectAssayForChart={(id) => {
                setSelectedAssayId(id);
                setCurrentTab('chart');
              }}
              onOpenManualEntry={() => setIsManualEntryOpen(true)}
              onOpenReceiver={() => setCurrentTab('receiver')}
              onOpenReport={() => setIsReportModalOpen(true)}
              onOpenCapaList={() => setCurrentTab('capa')}
              onOpenConfig={() => setCurrentTab('config')}
            />
          )}

          {/* Tab 2: Levey-Jennings Chart (Hỗ trợ xem đa biểu đồ theo máy hoặc theo xét nghiệm) */}
          {currentTab === 'chart' && (
            <MultiChartGridView
              instruments={appState.instruments}
              assays={appState.assays}
              lots={appState.lots}
              results={appState.results}
              selectedAssayId={selectedAssayId}
              onSelectAssay={(id) => setSelectedAssayId(id)}
              onSelectResultForCapa={(res) => {
                setSelectedResultForCapa(res);
                setIsCapaModalOpen(true);
              }}
              onOpenManualEntry={() => setIsManualEntryOpen(true)}
              onOpenReportModal={() => setIsReportModalOpen(true)}
            />
          )}

          {/* Tab 3: QC Master Data & Mean/SD Audit Trail */}
          {currentTab === 'config' && (
            <QCConfigView
              instruments={appState.instruments}
              assays={appState.assays}
              lots={appState.lots}
              materials={appState.materials || []}
              qcMappings={appState.qcMappings || []}
              meanSdAuditHistory={appState.meanSdAuditHistory || []}
              currentUser={appState.currentUser}
              users={appState.users || []}
              labInfo={appState.labInfo}
              onSaveLabInfo={handleSaveLabInfo}
              onUpdateLot={handleUpdateLot}
              onDeleteLot={handleDeleteLot}
              onSaveAssay={handleSaveAssay}
              onDeleteAssay={handleDeleteAssay}
              onSaveInstrument={handleSaveInstrument}
              onDeleteInstrument={handleDeleteInstrument}
              onSaveUser={handleSaveUser}
              onDeleteUser={handleDeleteUser}
              onSaveMaterial={handleSaveMaterial}
              onDeleteMaterial={handleDeleteMaterial}
              onSaveMapping={handleSaveMapping}
              onDeleteMapping={handleDeleteMapping}
            />
          )}

          {/* Tab 4: Machine Signal Receiver */}
          {currentTab === 'receiver' && (
            <MachineSignalReceiver
              instruments={appState.instruments}
              assays={appState.assays}
              lots={appState.lots}
              currentUser={appState.currentUser}
              onNewQCResult={handleAddNewResult}
              onOpenChart={(id) => {
                setSelectedAssayId(id);
                setCurrentTab('chart');
              }}
              onOpenCapa={(res) => {
                setSelectedResultForCapa(res);
                setIsCapaModalOpen(true);
              }}
            />
          )}

          {/* Tab 4: CAPA Register */}
          {currentTab === 'capa' && (
            <CapaListView
              results={appState.results}
              assays={appState.assays}
              instruments={appState.instruments}
              currentUser={appState.currentUser}
              onOpenCapaModal={(res) => {
                setSelectedResultForCapa(res);
                setIsCapaModalOpen(true);
              }}
              onOpenChart={(id) => {
                setSelectedAssayId(id);
                setCurrentTab('chart');
              }}
            />
          )}

          {/* Tab 5: Reports */}
          {currentTab === 'reports' && (
            <div className="bg-white rounded-xl border border-slate-200 p-8 text-center space-y-4">
              <div className="w-12 h-12 rounded-full bg-cyan-50 text-cyan-700 flex items-center justify-center mx-auto">
                <FileText className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Xuất Báo Cáo Nội Kiểm Định Kỳ (PDF)
                </h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto mt-1">
                  Tạo báo cáo tháng tiêu chuẩn y khoa với đầy đủ chỉ số thống kê Mean, SD, CV%, SDI, Six Sigma, biểu đồ L-J và 3 chữ ký thẩm định.
                </p>
              </div>
              <button
                onClick={() => setIsReportModalOpen(true)}
                className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors inline-flex items-center gap-2"
              >
                <FileText className="w-4 h-4 text-cyan-400" />
                <span>Khởi Tạo Báo Cáo A4 Ngay</span>
              </button>
            </div>
          )}

          {/* Tab 6: Backup & Audit */}
          {currentTab === 'backup' && (
            <BackupRestoreView
              appState={appState}
              isOnline={isOnline}
              onToggleOnline={() => setIsOnline(!isOnline)}
              onRestoreState={(newState) => setAppState(newState)}
              onForceSync={handleForceSync}
              onOpenUpdateModal={() => setIsUpdateModalOpen(true)}
            />
          )}
        </main>
      ) : (
        <main className="flex-1 flex items-center justify-center p-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-8 max-w-md w-full text-center space-y-4 shadow-md">
            <div className="w-14 h-14 rounded-2xl bg-slate-900 text-white flex items-center justify-center mx-auto font-extrabold text-2xl tracking-tight border-2 border-cyan-500/40 select-none">
              TX
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Hệ Thống Đã Đăng Xuất & Khóa Truy Cập
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Vui lòng xác thực tài khoản và mật khẩu để truy cập dữ liệu nội kiểm xét nghiệm.
              </p>
            </div>
            <button
              onClick={() => setIsLoginModalOpen(true)}
              className="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors cursor-pointer"
            >
              Đăng Nhập Lại Ngay
            </button>
          </div>
        </main>
      )}

      {/* Modals */}
      <UserRoleSwitcherModal
        isOpen={isUserModalOpen}
        onClose={() => setIsUserModalOpen(false)}
        currentUser={appState.currentUser}
        onSelectUser={handleSelectUser}
        onRequestSwitchAccount={() => setIsLoginModalOpen(true)}
      />

      <CapaModal
        isOpen={isCapaModalOpen}
        onClose={() => {
          setIsCapaModalOpen(false);
          setSelectedResultForCapa(null);
        }}
        result={selectedResultForCapa}
        assay={appState.assays.find((a) => a.id === selectedResultForCapa?.assayId)}
        currentUser={appState.currentUser}
        onSaveCapa={handleSaveCapa}
      />

      <ManualEntryModal
        isOpen={isManualEntryOpen}
        onClose={() => setIsManualEntryOpen(false)}
        instruments={appState.instruments}
        assays={appState.assays}
        lots={appState.lots}
        currentUser={appState.currentUser}
        historicalResults={appState.results}
        onAddResult={handleAddNewResult}
        onAddResults={handleAddNewResults}
      />

      <QCReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        instruments={appState.instruments}
        assays={appState.assays}
        lots={appState.lots}
        results={appState.results}
        currentUser={appState.currentUser}
        labInfo={appState.labInfo}
      />

      <LoginModal
        isOpen={!isLoggedIn || isLoginModalOpen}
        strictMode={!isLoggedIn}
        users={appState.users || []}
        onLoginSuccess={(u) => {
          saveCurrentUser(u);
          const log: AuditLog = {
            id: `log_login_${Date.now()}`,
            timestamp: new Date().toISOString(),
            userId: u.id,
            userName: u.name,
            role: u.role,
            action: 'ĐĂNG_NHẬP_HỆ_THỐNG',
            details: `Xác thực và đăng nhập thành công tài khoản ${u.name} (@${u.username}).`,
          };
          saveAuditLog(log);
          setAppState((prev) => ({ ...prev, currentUser: u, logs: [log, ...prev.logs] }));
          setIsLoggedIn(true);
          localStorage.setItem('qc_lab_is_logged_in', 'true');
          setIsLoginModalOpen(false);
        }}
        onClose={() => {
          if (isLoggedIn) setIsLoginModalOpen(false);
        }}
      />

      <UpdateCheckModal
        isOpen={isUpdateModalOpen}
        onClose={() => setIsUpdateModalOpen(false)}
      />

      <LabInfoModal
        isOpen={isLabInfoModalOpen}
        onClose={() => setIsLabInfoModalOpen(false)}
        labInfo={appState.labInfo}
        onSaveLabInfo={handleSaveLabInfo}
      />
    </div>
  );
}
